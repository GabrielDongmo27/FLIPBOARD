﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// Pour plus d'informations sur le modèle d'élément Page vierge, consultez la page https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace Presentation
{
    public class Album
    {
        public string AlbumImage { get; set; }
        public string AlbumName { get; set; }
        public string AlbumArtist { get; set; }
        public int AlbumDate { get; set; }

        public Album(string name, string artist, string image, int year)
        {
            AlbumName = name;
            AlbumArtist = artist;
            AlbumImage = image;
            AlbumDate = year;
        }
    }

    public sealed partial class MainPage : Page
    {
        List<Album> Albums = new List<Album>();

        public MainPage()
        {
            this.InitializeComponent();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);

            InitImage();
            flipView.ItemsSource = Albums;
        }

        private void InitImage()
        {
            Albums.Add(new Album("ASTROWORLD", "Travis Scott", "ms-appx:///Assets/Images/astroworld.jpg", 2018));
            Albums.Add(new Album(".RAW", "Laylow", "ms-appx:///Assets/Images/.raw.jpg", 2018));
            Albums.Add(new Album("BEAUTIFUL THUGGER GIRLS", "Young Thug", "ms-appx:///Assets/Images/beautifulthuggergirls.jpg", 2017));
            Albums.Add(new Album("DIE LIT", "Playboi Carti", "ms-appx:///Assets/Images/dielit.jpg", 2018));
            Albums.Add(new Album("QUAVO HUNCHO", "Quavo", "ms-appx:///Assets/Images/quavohuncho.jpg", 2018));
            Albums.Add(new Album("CULTURE", "Migos", "ms-appx:///Assets/Images/culture.jpg", 2017));

        }
    }
}
