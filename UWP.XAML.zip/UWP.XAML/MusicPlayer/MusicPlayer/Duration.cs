﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MusicPlayer
{
    class Duration
    {
        public int Minutes { get; set; }
        public int Seconds { get; set; }

        public Duration(int m, int s)
        {
            Minutes = m;
            Seconds = s;
        }
    }
}
