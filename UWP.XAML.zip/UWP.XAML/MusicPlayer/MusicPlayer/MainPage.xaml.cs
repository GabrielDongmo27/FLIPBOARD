﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// Pour plus d'informations sur le modèle d'élément Page vierge, consultez la page https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace MusicPlayer
{
    public sealed partial class MainPage : Page
    {
        List<Album> Albums = new List<Album>();

        public MainPage()
        {
            this.InitializeComponent();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);

            InitAlbum();
            
        }

        private void InitAlbum()
        {
            List<Music> Musics = new List<Music>()
            {
                new Music("STARGAZING", new Duration(04, 30)),
                new Music("CAROUSEL", new Duration(03, 00)),
                new Music("SICKO MODE", new Duration(05, 12)),
                new Music("R.I.P. SCREW", new Duration(03, 05)),
                new Music("STOP TRYING TO BE GOD", new Duration(05, 38)),
                new Music("NO BYSTANDERS", new Duration(03, 38)),
                new Music("SKELETONS", new Duration(02, 25)),
                new Music("WAKE UP", new Duration(03, 52)),
                new Music("5% TINT", new Duration(03, 16)),
                new Music("NC-17", new Duration(02, 36)),
                new Music("ASTROTHUNDER", new Duration(02, 23)),
                new Music("YOSEMITE", new Duration(02, 30)),
                new Music("CAN'T SAY", new Duration(03, 18)),
                new Music("WHO? WHAT!", new Duration(02, 56)),
                new Music("BUTTERFLY EFFECT", new Duration(03, 10)),
                new Music("HOUSTONFORNICATION", new Duration(03, 37)),
                new Music("COFFEE BEAN", new Duration(03, 29))
            }; 

            Albums.Add(new Album("ASTROWORLD", "Travis Scott", "ms-appx:///Assets/Images/photo_2018-12-21_16-11-20.jpg", 2018, Musics));
        }
    }
}
