﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml.Controls;

namespace MusicPlayer
{
    class Album: ListBox
    {
        public string AlbumName { get; set; }
        public string AlbumArtist { get; set; }
        public string AlbumImage { get; set; }
        public int AlbumDate { get; set; }
        public List<Music> Musics { get; set; }

        public Album(string name, string artist, string image, int date, List<Music> musics)
        {
            AlbumName = name;
            AlbumArtist = artist;
            AlbumImage = image;
            AlbumDate = date;
            Musics = musics;
        }
    }
}
