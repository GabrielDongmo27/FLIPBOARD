﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// Pour plus d'informations sur le modèle d'élément Page vierge, consultez la page https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace FlipBoard_UWP
{
    public class MyItem
    {
        public string ImagePath { get; set; }
        public string ImageName { get; set; }
    }

    public sealed partial class MainPage : Page
    {
        List<MyItem> Images = new List<MyItem>();

        public MainPage()
        {
            this.InitializeComponent();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);

            InitImage();
            flipView.ItemsSource = Images;
        }

        private void InitImage()
        {
            Images.Add(new MyItem() { ImageName = "PRhyme - PRhyme (Deluxe)", ImagePath = "ms-appx:///Assets/Images/IMG_1357.JPG" });
            Images.Add(new MyItem() { ImageName = "Playboi Carti - Die Lit", ImagePath = "ms-appx:///Assets/Images/IMG_20210114_182313_403.jpg" });
            Images.Add(new MyItem() { ImageName = "Migos - Culture", ImagePath = "ms-appx:///Assets/Images/photo_2018-12-07_07-48-56.jpg" });
            Images.Add(new MyItem() { ImageName = "Migos - Culture II", ImagePath = "ms-appx:///Assets/Images/photo_2018-12-13_05-55-34.jpg" });
            Images.Add(new MyItem() { ImageName = "Travis Scott - ASTROWORLD", ImagePath = "ms-appx:///Assets/Images/photo_2018-12-21_16-11-20.jpg" });
            Images.Add(new MyItem() { ImageName = "Young Thug - Beautiful Thugger Girls", ImagePath = "ms-appx:///Assets/Images/photo_2019-01-05_12-26-47.jpg" });
            Images.Add(new MyItem() { ImageName = "Gunna - Drip Season 3 (Deluxe)", ImagePath = "ms-appx:///Assets/Images/photo_2019-04-13_16-38-43.jpg" });
        }
    }
}
